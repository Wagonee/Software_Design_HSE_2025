﻿namespace Frontend.Models;

public class AccountDto
{
    public Guid Id { get; set; }
    public string UserId { get; set; }
    public decimal Balance { get; set; }
}