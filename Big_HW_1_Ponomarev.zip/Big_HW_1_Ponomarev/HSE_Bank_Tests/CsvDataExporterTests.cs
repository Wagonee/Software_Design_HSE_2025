﻿using System.Text;
using HSE_Bank.Infrastructure.Exporters;
using HSE_Bank.Domain.Entities;

namespace HSE_Bank_Tests
{
    public class CsvDataExporterTests : IDisposable
    {
        private readonly string _tempFolder;
        private readonly string _exportFolder;

        public CsvDataExporterTests()
        {
            _tempFolder = Path.Combine(Path.GetTempPath(), Guid.NewGuid().ToString());
            Directory.CreateDirectory(_tempFolder);
            Directory.SetCurrentDirectory(_tempFolder);
            _exportFolder = Path.Combine(_tempFolder, "Export");
        }

        [Fact]
        public void ExportBankAccount_AppendsCorrectCsvLine()
        {
            var exporter = new CsvDataExporter();
            var account = new BankAccount { Id = 2, Name = "CSV Account", Balance = 250.0m };
            string expectedFilePath = Path.Combine(_exportFolder, "accounts.csv");

            exporter.ExportBankAccount(account);

            Assert.True(File.Exists(expectedFilePath));

            string[] lines = File.ReadAllLines(expectedFilePath, Encoding.UTF8);
            Assert.Single(lines);
            string expectedLine = $"{account.Id},{account.Name},{account.Balance}";
            Assert.Equal(expectedLine, lines.First().Trim());
        }

        public void Dispose()
        {
            try
            {
                Directory.SetCurrentDirectory(Path.GetTempPath());
                if (Directory.Exists(_tempFolder))
                {
                    Directory.Delete(_tempFolder, true);
                }
            }
            catch { }
        }
    }
}