﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Text.Json;
using Xunit;
using HSE_Bank.Infrastructure.Exporters;
using HSE_Bank.Domain.Entities;

namespace HSE_Bank_Tests
{
    public class JsonDataExporterTests : IDisposable
    {
        private readonly string _tempFolder;
        private readonly string _exportFolder;

        public JsonDataExporterTests()
        {
            // Создаем временную папку для тестов
            _tempFolder = Path.Combine(Path.GetTempPath(), Guid.NewGuid().ToString());
            Directory.CreateDirectory(_tempFolder);
            // Для тестов устанавливаем текущую директорию как временную
            Directory.SetCurrentDirectory(_tempFolder);
            // Экспортёры создают папку "Export" в текущей директории
            _exportFolder = Path.Combine(_tempFolder, "Export");
        }

        [Fact]
        public void ExportBankAccount_CreatesFileWithCorrectJson()
        {
            // Arrange
            var exporter = new JsonDataExporter();
            var account = new BankAccount { Id = 1, Name = "Test Account", Balance = 100.0m };
            string expectedFilePath = Path.Combine(_exportFolder, "accounts.json");

            // Act
            exporter.ExportBankAccount(account);

            // Assert
            Assert.True(File.Exists(expectedFilePath));

            string jsonContent = File.ReadAllText(expectedFilePath);
            var accounts = JsonSerializer.Deserialize<List<BankAccount>>(jsonContent);

            Assert.NotNull(accounts);
            Assert.Single(accounts);
            Assert.Equal(account.Id, accounts[0].Id);
            Assert.Equal(account.Name, accounts[0].Name);
            Assert.Equal(account.Balance, accounts[0].Balance);
        }

        public void Dispose()
        {
            // Очистка: возвращаем исходную текущую директорию и удаляем временную папку
            try
            {
                Directory.SetCurrentDirectory(Path.GetTempPath());
                if (Directory.Exists(_tempFolder))
                {
                    Directory.Delete(_tempFolder, true);
                }
            }
            catch { }
        }
    }
}
