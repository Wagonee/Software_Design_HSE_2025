﻿using System.Windows.Input;

namespace HSE_Bank.Domain.Interfaces.Commands;

public interface ICommands
{
    void Execute();
}